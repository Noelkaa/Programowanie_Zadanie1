﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdvancedProgramming_Lesson1.Data;
using AdvancedProgramming_Lesson1.Models;

namespace AdvancedProgramming_Lesson1.Controllers
{
    public class DairiesController : Controller
    {
        private readonly MvcDairyContext _context;

        public DairiesController(MvcDairyContext context)
        {
            _context = context;
        }

        // GET: Dairies
        public async Task<IActionResult> Index()
        {
            return View(await _context.Dairy.ToListAsync());
        }

        // GET: Dairies/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dairy = await _context.Dairy
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dairy == null)
            {
                return NotFound();
            }

            return View(dairy);
        }

        // GET: Dairies/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Dairies/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EatByDate,Type,Weight,FatContent,Price")] Dairy dairy)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dairy);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dairy);
        }

        // GET: Dairies/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dairy = await _context.Dairy.FindAsync(id);
            if (dairy == null)
            {
                return NotFound();
            }
            return View(dairy);
        }

        // POST: Dairies/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,EatByDate,Type,Weight,FatContent,Price")] Dairy dairy)
        {
            if (id != dairy.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dairy);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DairyExists(dairy.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dairy);
        }

        // GET: Dairies/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dairy = await _context.Dairy
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dairy == null)
            {
                return NotFound();
            }

            return View(dairy);
        }

        // POST: Dairies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dairy = await _context.Dairy.FindAsync(id);
            _context.Dairy.Remove(dairy);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DairyExists(int id)
        {
            return _context.Dairy.Any(e => e.Id == id);
        }
    }
}

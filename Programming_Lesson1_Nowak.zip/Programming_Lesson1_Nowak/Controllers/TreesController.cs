﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdvancedProgramming_Lesson1.Data;
using AdvancedProgramming_Lesson1.Models;

namespace AdvancedProgramming_Lesson1.Controllers
{
    public class TreesController : Controller
    {
        private readonly MvcTreesContext _context;

        public TreesController(MvcTreesContext context)
        {
            _context = context;
        }

        // GET: Trees
        public async Task<IActionResult> Index()
        {
            return View(await _context.Trees.ToListAsync());
        }

        // GET: Trees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var trees = await _context.Trees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (trees == null)
            {
                return NotFound();
            }

            return View(trees);
        }

        // GET: Trees/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Trees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Height,Type,PlantingDate,TrunkDiameter,LeafColor")] Trees trees)
        {
            if (ModelState.IsValid)
            {
                _context.Add(trees);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(trees);
        }

        // GET: Trees/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var trees = await _context.Trees.FindAsync(id);
            if (trees == null)
            {
                return NotFound();
            }
            return View(trees);
        }

        // POST: Trees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Height,Type,PlantingDate,TrunkDiameter,LeafColor")] Trees trees)
        {
            if (id != trees.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(trees);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TreesExists(trees.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(trees);
        }

        // GET: Trees/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var trees = await _context.Trees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (trees == null)
            {
                return NotFound();
            }

            return View(trees);
        }

        // POST: Trees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var trees = await _context.Trees.FindAsync(id);
            _context.Trees.Remove(trees);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TreesExists(int id)
        {
            return _context.Trees.Any(e => e.Id == id);
        }
    }
}

﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcTreesContext : DbContext
    {
        public MvcTreesContext(DbContextOptions<MvcTreesContext> options)
        : base(options)
        {
        }
        public DbSet<Trees> Trees { get; set; }
    }
}

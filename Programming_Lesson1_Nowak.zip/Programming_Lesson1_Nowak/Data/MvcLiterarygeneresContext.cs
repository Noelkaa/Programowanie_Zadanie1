﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcLiterarygeneresContext : DbContext
    {
        public MvcLiterarygeneresContext(DbContextOptions<MvcLiterarygeneresContext> options)
        : base(options)
        {
        }
        public DbSet<Literarygeneres> Literarygeneres { get; set; }
    }
}

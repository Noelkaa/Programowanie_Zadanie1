﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcPotsContext : DbContext
    {
        public MvcPotsContext(DbContextOptions<MvcPotsContext> options)
        : base(options)
        {
        }
        public DbSet<Pots> Pots { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Vegetables
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Display(Name = "Typ warzywa")]
        public string Type { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data siewu")]
        public DateTime SowingDate { get; set; }
        [DataType(DataType.Date)]

        [Display(Name = "Data zbioru")]
        public DateTime HarvestDate { get; set; }
        [Display(Name = "Waga")]
        public decimal Weight { get; set; }
        [Display(Name = "Cena")]
        public decimal Price { get; set; }
    }
}

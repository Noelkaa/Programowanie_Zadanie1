﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Fruits
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data przydatności do spożycia")]
        public DateTime EatByDate { get; set; }

        [Display(Name = "Rodzaj (np. jabłko, banan)")]
        public string Type { get; set; }

        [Display(Name = "Waga")]
        public  decimal Weight { get; set; }
        [Display(Name = "Zawartość witaminy C (mg/100 g)")]
        public decimal VitaminC { get; set; }
      
        [Display(Name = "Cena")]
        public decimal Price { get; set; }
    }
}

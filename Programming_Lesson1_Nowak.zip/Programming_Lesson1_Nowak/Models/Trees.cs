﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Trees
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Display(Name = "Wysokość (m)")]
        public int Height { get; set; }

        [Display(Name = "Rodzaj")]
        public string Type { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data posadzenia")]
        public DateTime PlantingDate{ get; set; }
        [Display(Name = "Średnica pnia (cm)")]
        public decimal TrunkDiameter{ get; set; }
        [Display(Name = "Kolor liści")]
        public string LeafColor { get; set; }
    }
}

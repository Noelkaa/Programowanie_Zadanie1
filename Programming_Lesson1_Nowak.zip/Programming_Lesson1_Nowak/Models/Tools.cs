﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Tools
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Display(Name = "Typ narzędzia")]
        public string Type { get; set; }

        [Display(Name = "Materiał wykonania")]
        public string Material { get; set; }
        [Display(Name = "Waga")]
        public decimal Weight { get; set; }
        [Display(Name = "Długość")]
        public decimal length { get; set; }
        [Display(Name = "Cena")]
        public decimal Price { get; set; }

    }
}

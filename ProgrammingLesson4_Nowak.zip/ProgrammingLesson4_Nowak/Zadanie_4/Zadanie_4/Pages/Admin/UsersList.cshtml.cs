using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Zadanie_4.Pages.Admin
{
    public class UsersListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
